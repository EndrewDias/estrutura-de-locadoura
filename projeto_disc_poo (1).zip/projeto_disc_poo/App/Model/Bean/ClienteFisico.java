package App.Model.Bean;

public class ClienteFisico extends Cliente{

    public String rg;
    public String cpf;
    public String sexo;
    public String dtnas;
    

}
