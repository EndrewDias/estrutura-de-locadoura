package App.Model.Bean;

public class Cliente {

    public String Nome;
    public String Sobrenome;
    public String Email;
    public String Telefone;



}
