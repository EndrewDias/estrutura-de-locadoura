package App.Model.Bean;

public class Veiculo {

    public String marca;
    public String modelo;
    public String ano;
    public String cor;
    public String diaria;
 
}
