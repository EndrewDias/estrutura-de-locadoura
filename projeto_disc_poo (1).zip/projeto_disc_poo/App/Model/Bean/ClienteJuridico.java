package App.Model.Bean;

public class ClienteJuridico extends Cliente {

    public String Nomefantasia;
    public String Razaosocial;
    public String Cnpj;
    
}
